"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[4652],{14652:(e,l,r)=>{r.r(l),r.d(l,{chevronLeftSvg:()=>n});var a=r(46797);let n=(0,a.JW)`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M11.04 1.46a1 1 0 0 1 0 1.41L5.91 8l5.13 5.13a1 1 0 1 1-1.41 1.41L3.79 8.71a1 1 0 0 1 0-1.42l5.84-5.83a1 1 0 0 1 1.41 0Z"
    clip-rule="evenodd"
  />
</svg>`}}]);