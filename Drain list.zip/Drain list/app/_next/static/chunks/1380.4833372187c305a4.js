"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[1380],{31380:(e,l,r)=>{r.r(l),r.d(l,{chevronTopSvg:()=>n});var a=r(46797);let n=(0,a.JW)`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M14.54 11.04a1 1 0 0 1-1.41 0L8 5.92l-5.13 5.12a1 1 0 1 1-1.41-1.41l5.83-5.84a1 1 0 0 1 1.42 0l5.83 5.84a1 1 0 0 1 0 1.41Z"
    clip-rule="evenodd"
  />
</svg>`}}]);