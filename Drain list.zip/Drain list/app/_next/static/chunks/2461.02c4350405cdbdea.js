"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[2461],{52461:(e,l,r)=>{r.r(l),r.d(l,{cursorSvg:()=>u});var s=r(46797);let u=(0,s.JW)` <svg fill="none" viewBox="0 0 13 4">
  <path fill="currentColor" d="M.5 0h12L8.9 3.13a3.76 3.76 0 0 1-4.8 0L.5 0Z" />
</svg>`}}]);